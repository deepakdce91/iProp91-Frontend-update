import PropCard from "../BuysCards/PropCard"


export default function MyProperty() {
    return (
        <>
            <div className="flex flex-row flex-wrap justify-center">
                <PropCard />
                <PropCard />
                <PropCard />
                <PropCard />
                <PropCard />
                <PropCard />
                <PropCard />
                <PropCard />
                <PropCard />
                <PropCard />
            </div>
        </>
    )
}