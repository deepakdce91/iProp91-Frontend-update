export default function ImageSection(){
    return (
        <>
        <div className="w-full">

          <img src="/images/landing.png" alt="" className="w-full" style={{
            zIndex: 5000,
          }} />
          </div>
        </>
    )
}